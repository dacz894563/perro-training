---
name: Warm Editorial Botanical Club
colors:
  surface: '#fcf9f2'
  surface-dim: '#dcdad3'
  surface-bright: '#fcf9f2'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ec'
  surface-container: '#f0eee7'
  surface-container-high: '#ebe8e1'
  surface-container-highest: '#e5e2db'
  on-surface: '#1c1c18'
  on-surface-variant: '#55433c'
  inverse-surface: '#31312c'
  inverse-on-surface: '#f3f0e9'
  outline: '#88726b'
  outline-variant: '#dbc1b8'
  surface-tint: '#9a4523'
  primary: '#994422'
  on-primary: '#ffffff'
  primary-container: '#b85c38'
  on-primary-container: '#ffffff'
  inverse-primary: '#ffb59a'
  secondary: '#47654f'
  on-secondary: '#ffffff'
  secondary-container: '#c6e8cc'
  on-secondary-container: '#4b6a53'
  tertiary: '#506253'
  on-tertiary: '#ffffff'
  tertiary-container: '#687b6b'
  on-tertiary-container: '#ffffff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59a'
  on-primary-fixed: '#380d00'
  on-primary-fixed-variant: '#7b2f0e'
  secondary-fixed: '#c9ebce'
  secondary-fixed-dim: '#adcfb3'
  on-secondary-fixed: '#03210f'
  on-secondary-fixed-variant: '#304d38'
  tertiary-fixed: '#d3e8d5'
  tertiary-fixed-dim: '#b8ccba'
  on-tertiary-fixed: '#0e1f14'
  on-tertiary-fixed-variant: '#394b3d'
  background: '#fcf9f2'
  on-background: '#1c1c18'
  surface-variant: '#e5e2db'
  clay-terracotta: '#B85C38'
  clay-terracotta-dark: '#8C3F22'
  clay-terracotta-light: '#E8B4A2'
  forest-canopy: '#263B2D'
  sage-botanical: '#6E8271'
  sage-wash: '#E4ECE5'
  canary-cream: '#FDFBF7'
  sand-neutral: '#EDE6DA'
  sand-border: '#DFD6C7'
  deep-charcoal: '#1F2321'
  charcoal-muted: '#525A55'
typography:
  display:
    fontFamily: Epilogue
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Epilogue
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Epilogue
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Epilogue
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Epilogue
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Epilogue
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: '0'
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 19px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: '0'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: '0'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: '0'
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style

This design system expresses the elevated, warm character of an architectural canine sanctuary located in Coyoacán. It marries contemporary Mexican residential architecture—earthy stucco, warm volcanic undertones, lush garden courtyards, and organic clay—with high-end hospitality and mindful training practices.

The aesthetic fuses **Warm Contemporary Editorial** with **Tactile Botanical Minimalism**:
- **Tone:** Grounded, affectionate, civilized, and serene. It eliminates the chaotic neon colors and cartoon aesthetics typical of mass-market pet stores.
- **Visual Personality:** A calm retreat reminiscent of boutique hospitality, artisan coffee spaces, and thoughtful landscape design.
- **Target Audience:** Design-conscious pet parents seeking certified, ethical dog training, curated social experiences, boutique boarding, and community gathering in Mexico City.

## Colors

The palette draws inspiration directly from Coyoacán’s historic facades, raw terracotta planters, shaded botanical courtyards, and woven natural fibers:

- **Primary (`#B85C38` Terracotta / Arcilla):** Used for primary conversion touchpoints, active states, key milestones, and expressive accents. Evokes fired clay tiles, warmth, and vitality.
- **Secondary (`#3E5C46` Warm Botanical Forest):** Signifies sanctuary, balance, wellness, and outdoor green fields. Ideal for membership badges, trust markers, and secondary action headers.
- **Tertiary (`#738676` Salvia Orgánico):** Provides soft structural accents, decorative icons, and botanical metadata tags.
- **Neutral Canvas (`#F8F5EE` Sand & Warm Cream):** Replaces pure digital white (`#FFFFFF`) with a comforting linen tone that prevents glare and evokes architectural lime plaster.
- **Deep Charcoal (`#1F2321` Carbón Profundo):** Replaces harsh pure black for typography and micro-borders, maintaining optimal legibility while remaining soft on warm backgrounds.

## Typography

The typographic pairing reflects thoughtful craft, structure, and approachable polish:

- **Headlines & Display (Epilogue):** An architectural, contemporary sans with humanist character and sculpted junctions. It provides distinct editorial gravitas suitable for boutique hospitality while feeling warm and natural.
- **Body & Functional UI (Plus Jakarta Sans):** A friendly, precision geometric sans with open counters and soft curvature. It delivers exceptional readability for schedule grids, service descriptions, pricing tables, and mobile bookings.
- **Scaling:** High-level headers step down proportionally on mobile viewports to prevent awkward line breaks and guarantee rhythm. Uppercase styling is reserved exclusively for small contextual labels and badge counters with generous tracking.

## Layout & Spacing

This design system embraces an open, airy 12-column layout on desktop, transitioning to a 6-column grid on tablet and a single/two-column fluid rhythm on mobile devices:

- **Desktop (1200px+):** Max-width container of `1240px` centered with `3rem` outer margins and `1.5rem` gutters. Ample vertical breathing room (`space-xl` and above) between architectural showcase sections.
- **Tablet (768px - 1199px):** `2rem` margins, allowing cards and programmatic modules to flex between 2-column pairing and stacked narratives.
- **Mobile (< 768px):** Minimal outer canvas margin (`1.25rem`) maximizes screen real estate for touch interactions, reservation forms, and card swiping.
- **Vertical Rhythm:** Section separators rely on natural tone transitions and white space rather than heavy dividing lines.

## Elevation & Depth

Visual hierarchy is maintained through soft architectural tonal layering rather than cold drop shadows:

- **Level 0 (Base Canvas):** `#F8F5EE` (Sand/Warm Cream base).
- **Level 1 (Card & Module Surface):** `#FDFBF7` (Canary Cream) edged by a delicate structural outline: `1px solid #DFD6C7`.
- **Level 2 (Interactive Floating Elements / Popovers / Modals):** Crisp `#FDFBF7` surface supported by an ambient, warm tinted shadow: `0 12px 32px -8px rgba(62, 42, 31, 0.08), 0 2px 6px -1px rgba(62, 42, 31, 0.04)`.
- **Level 3 (Sticky Booking Bar & Critical Drawers):** High-focus surface elevated with: `0 20px 48px -12px rgba(31, 35, 33, 0.12)`.
- **Embossed Accents:** Inner cards within suite overviews or membership tiers utilize tinted backdrops (such as `#E4ECE5` Sage Wash) with zero shadow for an organic, editorial feel.

## Shapes

The shape system employs consistent **Level 2 Roundedness** (0.5rem base) with organic adaptations:
- Standard interactive elements (input fields, action buttons, alert boxes) use `0.5rem` (8px) border radius.
- Cards, modal containers, and architectural image viewports use `rounded-lg` (`1rem` / 16px) or `rounded-xl` (`1.5rem` / 24px) to simulate gently rounded masonry and sanded woodwork.
- Badges, pills, and status tags adopt full capsule shapes (`rounded-full`) to complement the warmth of the layout.

## Components

### Buttons
- **Primary Action:** Solid Terracotta (`#B85C38`) with Canary Cream text (`#FDFBF7`). Subtle elevation on hover (`translate-y-[-1px]`) and transition to `#8C3F22`. Height: 48px; border-radius: 8px; font-weight: 600.
- **Secondary Action:** Transparent base with Forest Green border (`1.5px solid #3E5C46`) and Forest Green text. On hover, fills with `#E4ECE5` (Sage wash).
- **Tertiary / Link Action:** Charcoal text (`#1F2321`) with an animated bottom underline in Terracotta.

### Cards & Service Tiles
- Constructed using Canary Cream background (`#FDFBF7`) framed by a subtle sand border (`#DFD6C7`).
- Image containers within cards feature an inner border-radius of `0.75rem` and an organic aspect ratio (4:3 or 16:10).
- Hover effect features a subtle elevation lift accompanied by the warm ambient shadow.

### Form Inputs & Selectors
- Background: `#FDFBF7` with a 1px border of `#DFD6C7`.
- Label placed in `label-sm` uppercase above the field with `#525A55` color.
- Focus State: Border transitions to `#B85C38` with an ethereal ring of `rgba(184, 92, 56, 0.16)`. No harsh browser outlines.

### Chips & Badges
- Filter chips and amenity tags (e.g., *"Cámaras 24/7"*, *"Patio Agility"*, *"Dieta BARF"*):
  - Inactive: `#EDE6DA` background, `#1F2321` typography, pill shape, `0.25rem 0.75rem` padding.
  - Active: `#3E5C46` background, `#FDFBF7` typography.

### Checkboxes & Radios
- Rounded squares (4px radius) for checkboxes; concentric rings for radios.
- Inactive: `#EDE6DA` fill with `#DFD6C7` stroke.
- Checked: `#B85C38` fill with a crisp `#FDFBF7` check icon.

### Bespoke Domain Components
- **Phase Roadmap Indicator:** Clean timeline showing base training, day club, pet parties, boutique hotel, and co-working cafe with soft sage completed icons and terracotta active flags.
- **Suite & Room Availability Pill:** Soft green micro-dot (`#3E5C46`) paired with `label-sm` text displaying real-time booking slots.